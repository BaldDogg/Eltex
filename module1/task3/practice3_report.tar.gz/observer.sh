#!/bin/bash

CONFIG_FILE="observer.conf"
LOG_FILE="observer.log"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "$(date): Конфигурационный файл $CONFIG_FILE не найден" >> "$LOG_FILE"
    exit 1
fi

while read -r script; do
    if [ -z "$script" ] || [[ "$script" = \#* ]]; then
        continue
    fi
    
    if ! pgrep -f "$script" > /dev/null; then
        echo "$(date): Перезапуск $script" >> "$LOG_FILE"
        nohup ./"$script" > /dev/null 2>&1 &
    fi
done < "$CONFIG_FILE"
