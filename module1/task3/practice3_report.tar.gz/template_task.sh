#!/bin/bash

SCRIPT_NAME=$(basename "$0")
if [ "$SCRIPT_NAME" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

REPORT_FILE="report_${SCRIPT_NAME%.*}.log"
echo "[$$] $(date) Скрипт запущен" >> "$REPORT_FILE"

RAND_SECONDS=$((30 + RANDOM % 1771))
sleep $RAND_SECONDS

MINUTES=$((RAND_SECONDS / 60))
echo "[$$] $(date) Скрипт завершился, работал $MINUTES минут" >> "$REPORT_FILE"
